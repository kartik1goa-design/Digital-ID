Digital ID Card & Employee Directory 🪪👨‍💻

A clean, modern, and fully responsive "Digital Identity Card and Employee Directory" built with native HTML5 and CSS3. Designed for tracking organizational data, displaying front/back ID passes, and offering interactive user profiles.

Features

Interactive ID Card Showcase:Includes both front and back views mimicking standard real-world corporate identity cards with security chips and validation tags.
Responsive Employee Directory:Built using modern CSS Grid and Flexbox grids that gracefully adapt to desktop, tablet, and mobile displays.
Hover Reveal Insights:Employee cards feature sliding overlay transitions on hover to quickly review auxiliary contact details and primary tech stacks.
Department Badges:Distinct, color-coded visual variations for *Development*, *Design*, *HR*, and *Marketing*.
Company Statistics Dashboard:Real-time visual metrics tracking active personnel, active departments, and recent onboarding counts.
Print Optimization (`@media print`):A custom layout configuration that isolates and formats identity credentials cleanly when exporting hard copies or PDF passes.

Technologies Used

HTML5:Semantic architecture (`<header>`, `<main>`, `<section>`).
CSS3:Custom Variables, Flexbox, CSS Grid, Transitions, Transformations, and Media Queries.
FontAwesome:Scalable vector iconography for cards and UI components.

Deliverables Structure

1. `index.html` - Core markup container structure.
2. `style.css` - Stylesheet containing layout grid engines and animations.
3. `README.md` - Documentation and setup reference.